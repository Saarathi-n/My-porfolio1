import React from 'react';

const Home = () => {
  return (
    <section className="section hero">
      <h1 className="home-name">Saarathi N</h1>
      <p className="home-profession">Full Stack Developer</p>
    </section>
  );
};

export default Home;